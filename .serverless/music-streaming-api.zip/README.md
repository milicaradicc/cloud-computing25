# CloudComputing25
Web application for storing, sharing, and streaming music content, built with AWS cloud services using a cloud-native architecture. Supports user registration, content browsing, rating, playlists, subscriptions, personalized recommendations, and offline playback. Administrators can manage artists and music content efficiently
