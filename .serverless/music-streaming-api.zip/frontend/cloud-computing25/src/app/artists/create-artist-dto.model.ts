export interface CreateArtistDto {
  name: string;
  biography: string;
  genres: string[];
}
