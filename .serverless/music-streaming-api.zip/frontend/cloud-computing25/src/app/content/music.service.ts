import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { Song } from './song.model';
import { Album } from './album.model';
import { Artist } from '../artists/artist.model';
import { environment } from '../../env/environment';
import { CreateSongDto } from './create-song-dto.model';

@Injectable({
  providedIn: 'root'
})
export class MusicService {
  constructor(private httpClient: HttpClient) { }

  addSong(song: FormData): Observable<Song> {
    for (let pair of song.entries()) {
      console.log(pair[0], pair[1]);
    }    
    return this.httpClient.post<Song>(
      environment.apiHost + `/song`,  
      song
    );
  }

  addAlbum(album: FormData): Observable<Album> {
    return this.httpClient.post<Album>(
      environment.apiHost + `/album`,  
      album
    );
  }

  getAllSongs() : Observable<Song[]> {
    return this.httpClient.get<Song[]>(environment.apiHost + `/songs`);
  }

  getAllAlbums() : Observable<Album[]> {
    return this.httpClient.get<Album[]>(environment.apiHost + `/albums`);
  }

}