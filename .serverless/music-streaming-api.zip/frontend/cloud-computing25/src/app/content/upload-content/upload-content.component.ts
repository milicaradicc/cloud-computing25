import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
import { MatChipInputEvent } from '@angular/material/chips';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { Artist } from '../../artists/artist.model';
import { MusicService } from '../music.service';
import { ArtistService } from '../../artists/artist.service';

export interface FileInfo {
  fileName: string;
  fileType: string;
  fileSize: number;
  createdDate: Date;
  modifiedDate: Date;
  duration?: number;
}

@Component({
  standalone: false,
  selector: 'app-upload-content',
  templateUrl: './upload-content.component.html',
  styleUrls: ['./upload-content.component.css']
})
export class UploadContentComponent implements OnInit {
  uploadForm: FormGroup;
  availableArtists: Artist[] = [];
  selectedGenres: string[] = [];
  coverImagePreview: string | null = null;
  selectedCoverImageName: string = '';
  selectedAudioFileName: string = '';
  singleAudioInfo: FileInfo | null = null;
  availableGenres: string[] = ['Pop', 'Rock', 'Hip Hop', 'Jazz', 'Electronic', 'Classical'];
  displayedColumns: string[] = ['trackNumber', 'title', 'file', 'genres', 'artists', 'duration', 'actions'];
  readonly separatorKeysCodes = [COMMA, ENTER] as const;

  constructor(private fb: FormBuilder, private musicService: MusicService, private artistService: ArtistService) {
    this.uploadForm = this.fb.group({
      type: ['single', Validators.required],
      title: ['', Validators.required],
      coverImage: [null],
      singleAudioFile: [null],
      releaseDate: [new Date()],
      description: [''],
      artists: [[], Validators.required],
      genres: [[]],
      songs: this.fb.array([])
    });
  }

  ngOnInit(): void {
    this.loadArtists();

    this.uploadForm.get('type')?.valueChanges.subscribe(type => {
      if (type === 'single') {
        this.songs.clear();
        this.uploadForm.get('singleAudioFile')?.setValidators([Validators.required]);
        this.uploadForm.get('singleAudioFile')?.updateValueAndValidity();
      } else {
        this.uploadForm.get('singleAudioFile')?.clearValidators();
        this.uploadForm.get('singleAudioFile')?.updateValueAndValidity();
        this.selectedAudioFileName = '';
        this.singleAudioInfo = null;
        this.uploadForm.patchValue({ singleAudioFile: null });
        if (this.songs.length === 0) this.addSong();
      }
    });

    this.uploadForm.get('singleAudioFile')?.setValidators([Validators.required]);
  }

  get songs(): FormArray {
    return this.uploadForm.get('songs') as FormArray;
  }

  addSong() {
    const songGroup = this.fb.group({
      title: ['', Validators.required],
      file: [null, Validators.required],
      fileName: [''],
      fileInfo: [null],
      genres: [[]],
      artists: [[], Validators.required],
      duration: [null],
      trackNumber: [this.songs.length + 1]
    });
    this.songs.push(songGroup);
  }

  removeSong(index: number) {
    this.songs.removeAt(index);
    this.updateTrackNumbers();
  }

  private updateTrackNumbers() {
    this.songs.controls.forEach((control, index) => {
      control.patchValue({ trackNumber: index + 1 });
    });
  }

  onCoverImageChange(event: any) {
    const file = event.target.files[0];
    if (!file) return;
    this.selectedCoverImageName = file.name;
    this.uploadForm.patchValue({ coverImage: file });

    const reader = new FileReader();
    reader.onload = (e) => this.coverImagePreview = e.target?.result as string;
    reader.readAsDataURL(file);
  }

  onSingleAudioFileChange(event: any) {
    const file = event.target.files[0];
    if (!file) return;
    this.selectedAudioFileName = file.name;
    this.singleAudioInfo = this.extractFileInfo(file);
    this.uploadForm.patchValue({ singleAudioFile: file });
    this.extractSingleAudioDuration(file);
  }

  private extractSingleAudioDuration(file: File) {
    const audio = new Audio();
    const objectUrl = URL.createObjectURL(file);
    audio.src = objectUrl;
    audio.addEventListener('loadedmetadata', () => {
      if (this.singleAudioInfo) this.singleAudioInfo.duration = Math.round(audio.duration);
      URL.revokeObjectURL(objectUrl);
    });
    audio.addEventListener('error', () => URL.revokeObjectURL(objectUrl));
  }

  onSongFileChange(event: any, index: number) {
    const file = event.target.files[0];
    if (!file) return;
    const songGroup = this.songs.at(index);
    const fileInfo = this.extractFileInfo(file);
    songGroup.patchValue({ file, fileName: file.name, fileInfo });
    this.extractAudioDuration(file, index);
  }

  private extractFileInfo(file: File): FileInfo {
    return {
      fileName: file.name,
      fileType: file.type,
      fileSize: file.size,
      createdDate: new Date(file.lastModified),
      modifiedDate: new Date(file.lastModified)
    };
  }

  private extractAudioDuration(file: File, songIndex: number) {
    const audio = new Audio();
    const objectUrl = URL.createObjectURL(file);
    audio.src = objectUrl;
    audio.addEventListener('loadedmetadata', () => {
      const duration = Math.round(audio.duration);
      const songGroup = this.songs.at(songIndex);
      songGroup.patchValue({ duration });
      const currentFileInfo = songGroup.get('fileInfo')?.value;
      if (currentFileInfo) {
        currentFileInfo.duration = duration;
        songGroup.patchValue({ fileInfo: currentFileInfo });
      }
      URL.revokeObjectURL(objectUrl);
    });
    audio.addEventListener('error', () => URL.revokeObjectURL(objectUrl));
  }

  addGenre(event: MatChipInputEvent): void {
    const value = (event.value || '').trim();
    if (value && !this.selectedGenres.includes(value)) this.selectedGenres.push(value);
    event.chipInput!.clear();
  }

  removeGenre(genre: string): void {
    const index = this.selectedGenres.indexOf(genre);
    if (index >= 0) this.selectedGenres.splice(index, 1);
  }

  addSongGenre(event: MatChipInputEvent, songIndex: number): void {
    const value = (event.value || '').trim();
    const songGroup = this.songs.at(songIndex);
    const currentGenres = songGroup.get('genres')?.value || [];
    if (value && !currentGenres.includes(value)) {
      currentGenres.push(value);
      songGroup.patchValue({ genres: currentGenres });
    }
    event.chipInput!.clear();
  }

  removeSongGenre(genre: string, songIndex: number): void {
    const songGroup = this.songs.at(songIndex);
    const currentGenres = songGroup.get('genres')?.value || [];
    const index = currentGenres.indexOf(genre);
    if (index >= 0) {
      currentGenres.splice(index, 1);
      songGroup.patchValue({ genres: currentGenres });
    }
  }

  getSongGenres(songIndex: number): string[] {
    return this.songs.at(songIndex).get('genres')?.value || [];
  }

  formatFileSize(bytes: number): string {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  formatDuration(seconds: number | undefined): string {
    if (!seconds || seconds === 0) return '--:--';
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  }

  submit() {
    if (this.uploadForm.invalid) {
      this.markFormGroupTouched(this.uploadForm);
      return;
    }

    const formValue = this.uploadForm.value;
    const formData = new FormData();

    if (formValue.coverImage) formData.append('coverImage', formValue.coverImage);

    if (formValue.type === 'single') {
      if (formValue.singleAudioFile) formData.append('audioFile', formValue.singleAudioFile);

      const singleData = {
        title: formValue.title,
        artists: formValue.artists,
        genres: formValue.genres,
        releaseDate: formValue.releaseDate,
        description: formValue.description,
        fileInfo: this.singleAudioInfo
      };
      formData.append('songData', JSON.stringify(singleData));
      this.musicService.addSong(formData).subscribe(
        res => console.log('Song uploaded:', res),
        err => console.error(err)
      );
    } else {
      // Album
      const albumData = {
        title: formValue.title,
        artists: formValue.artists,
        genres: formValue.genres,
        releaseDate: formValue.releaseDate,
        description: formValue.description,
        songs: formValue.songs.map((song: any, index: number) => ({
          ...song,
          trackNumber: index + 1
        }))
      };

      formValue.songs.forEach((song: any, index: number) => {
        if (song.file) {
          formData.append(`songFile_${index}`, song.file);
          formData.append(`songMetadata_${index}`, JSON.stringify({
            title: song.title,
            artists: song.artists,
            genres: song.genres,
            trackNumber: song.trackNumber,
            fileInfo: song.fileInfo
          }));
        }
      });

      formData.append('albumData', JSON.stringify(albumData));
      this.musicService.addAlbum(formData).subscribe(
        res => console.log('Album uploaded:', res),
        err => console.error(err)
      );
    }
  }

  private markFormGroupTouched(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(key => {
      const control = formGroup.get(key);
      control?.markAsTouched();
      if (control instanceof FormGroup) this.markFormGroupTouched(control);
    });
  }

  private loadArtists(): void {
    this.artistService.getAll().subscribe(
      artists => this.availableArtists = artists,
      error => console.error('Error loading artists:', error)
    );
  }
}
