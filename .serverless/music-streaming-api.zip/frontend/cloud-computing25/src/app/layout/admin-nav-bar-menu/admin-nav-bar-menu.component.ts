import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-nav-bar-menu',
  standalone: false,
  templateUrl: './admin-nav-bar-menu.component.html',
  styleUrl: './admin-nav-bar-menu.component.css'
})
export class AdminNavBarMenuComponent {

}
