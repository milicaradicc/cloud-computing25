import { Component } from '@angular/core';

@Component({
  selector: 'app-user-nav-bar-menu',
  standalone: false,
  templateUrl: './user-nav-bar-menu.component.html',
  styleUrl: './user-nav-bar-menu.component.css'
})
export class UserNavBarMenuComponent {

}
