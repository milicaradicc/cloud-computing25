export const environment = {
  apiHost: 'https://gy56x4bn47.execute-api.eu-north-1.amazonaws.com/dev',
};
